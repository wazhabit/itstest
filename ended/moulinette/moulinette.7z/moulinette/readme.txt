Hey FX or other !
i heard you need a "Moulinette" ?
This is the version ALPHA, this executable will work like this :
go in your terminal and execute "moulinette" (it is in C compiled with GCC).
it can be use only in your terminal.

The syntaxe for use it is :

    	    ./moulinette <name_of_directory> <name_of_file_suffix_need>

For example (PC-FUNDAMENTALS) :

    	    ./moulinette ITS1_PC-FUNDAMENTALS ITS_PC-FUNDAMENTALS.txt

/!\ WARNING you need to precise ".txt" ! /!\

The programm will move in the directory mentionned (here ITS1_PC-FUNDAMENTALS) the valid or unvalid name of the files.


For example : Anatole_Piveteau_ITS-PC-FUNDAMENTALS.txt will be move in ITS1_PC-FUNDAMENTALS/unvalid

    	      ANatole_Piveteau_ITS_PC-FUNDAMENTALS.txt will be move in the same directory

	      Anatole_Piveteau_ITS_PC-FUNDAMENTALS.txt will be move in ITS1_PC-FUNDAMENTALS/valid

I let you my test directory, to complete my example, use moulinette like this :

  Put your terminal in the moulinette folder and type :
      ./moulinette Test_ITS1_PC-FUNDAMENTALS ITS_PC-FUNDAMENTALS.txt

Enjoy !

I will send you other version of moulinette, here i was a little bit taken this week end.

Here this is a ALPHA version, be indulgent ;)
